# AGENTS

## Project overview

This repository is a Spring Boot 3/4-style Java service for managing football clubs. The application is organized by package responsibility under `com.fatec.time`:

- `controllers/`: REST endpoints
- `services/`: business logic
- `repositories/`: Spring Data repositories
- `entities/`: JPA entities
- `dtos/`: request/response DTOs
- `mappers/`: conversion logic between entities and DTOs

The app boots from `TimeApplication` and uses Spring MVC + Spring Data JPA with an embedded H2 database in development.

## Build and verification

Use Maven wrapper commands from the repo root:

- `./mvnw test` — run the automated test suite
- `./mvnw spring-boot:run` — start the app locally
- `./mvnw clean package` — build the project artifact

Prefer the Maven wrapper over a system-wide Maven installation so the project version stays consistent.

## Code conventions

- Write idiomatic Java 21 code with clear class and method names.
- Keep package boundaries clean: controller logic belongs in `controllers`, persistence in `repositories`, and validation/business rules in `services`.
- Use JPA entities in `entities/` with `@Entity` and table mappings, and keep them simple domain objects.
- Prefer records for DTOs when they are immutable payloads, but keep the project style consistent when editing existing code.
- Validate request payloads with Jakarta Bean Validation annotations such as `@NotBlank`, `@NotNull`, and domain-specific messages.
- Preserve the established project naming pattern (`Time`, `TimeRequest`, `TimeService`, etc.) unless a refactor explicitly requires renaming.
- Keep XML/Java config minimal; prefer Spring Boot auto-configuration and framework conventions already present in the project.

## Important project-specific notes

- The project is configured in `pom.xml` to use Java 21 and Spring Boot 4.1.1.
- The default application properties file is intentionally minimal; do not add unnecessary configuration unless required for the task.
- The repository currently has empty `controllers`, `services`, `repositories`, and `mappers` directories, so new code should match the existing architectural intent rather than introducing unrelated patterns.
- The `HELP.md` file contains the reference documentation and is a useful starting point when checking framework conventions.

## Editing guidance

- Do not add unrelated frameworks or architectural layers without a clear reason.
- When adding a new entity or DTO, keep naming and field conventions aligned with the existing `Time` model.
- When fixing or implementing code, prefer the smallest change that matches the app’s Spring Boot structure and the existing package layout.
- Keep validation messages in Portuguese when they are user-facing, since the current DTO logic and domain naming use that language.

## Validation checklist before completion

Before claiming the task is done:

1. Ensure the relevant Java files compile under the project’s Maven configuration.
2. Run the focused test command for the affected area, or `./mvnw test` if the change is broad.
3. Confirm the project still follows the existing Spring Boot + JPA structure without introducing inconsistent packages or naming.

package com.fatec.time.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fatec.time.dtos.TimeRequest;
import com.fatec.time.dtos.TimeResponse;
import com.fatec.time.entities.Time;
import com.fatec.time.mappers.TimeMapper;
import com.fatec.time.repositories.TimeRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class TimeService {

    private final TimeRepository repository;

    TimeService(TimeRepository repository) {
        this.repository = repository;
    }

    public List<TimeResponse> findAll() {

        return repository.findAll()
                .stream()
                .map(TimeMapper::toDTO)
                .toList();
    }

    public TimeResponse findById(Long id) {

        Time time = repository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException());

        return TimeMapper.toDTO(time);
    }

    public void deleteById(Long id) {

        if (repository.existsById(id))
            repository.deleteById(id);
        else
            throw new EntityNotFoundException("Time não cadastrado");
    }

    public TimeResponse save(TimeRequest time) {

        Time t = repository.save(TimeMapper.toEntity(time));

        return TimeMapper.toDTO(t);
    }

    public void update(TimeRequest time, Long id) {

        Time t = repository.findById(id)
                .orElseThrow(() ->
                    new EntityNotFoundException("Time não cadastrado"));

        t.setNome(time.nome());
        t.setCidade(time.cidade());
        t.setEstado(time.estado());
        t.setEstadio(time.estadio());
        t.setAnoFundacao(time.anoFundacao());

        repository.save(t);
    }
}
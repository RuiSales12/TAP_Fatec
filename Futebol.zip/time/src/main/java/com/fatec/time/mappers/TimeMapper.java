package com.fatec.time.mappers;

import com.fatec.time.dtos.TimeRequest;
import com.fatec.time.dtos.TimeResponse;
import com.fatec.time.entities.Time;

public class TimeMapper {

    public static Time toEntity(TimeRequest request) {

        Time time = new Time();

        time.setNome(request.nome());
        time.setCidade(request.cidade());
        time.setEstado(request.estado());
        time.setEstadio(request.estadio());
        time.setAnoFundacao(request.anoFundacao());

        return time;
    }

    public static TimeResponse toDTO(Time time) {

        return new TimeResponse(
            time.getId(),
            time.getNome(),
            time.getCidade(),
            time.getEstado(),
            time.getEstadio(),
            time.getAnoFundacao()
        );
    }
}
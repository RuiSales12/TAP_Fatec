package com.fatec.time.dtos;

public record TimeResponse(
    Long id,
    String nome,
    String cidade,
    String estado,
    String estadio,
    Integer anoFundacao
) {

}
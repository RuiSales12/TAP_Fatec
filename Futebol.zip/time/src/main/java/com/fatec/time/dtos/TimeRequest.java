package com.fatec.time.dtos;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record TimeRequest(

    @NotBlank(message = "Nome é obrigatório")
    String nome,

    @NotBlank(message = "Cidade é obrigatória")
    String cidade,

    @NotBlank(message = "Estado é obrigatório")
    String estado,

    @NotBlank(message = "Estádio é obrigatório")
    String estadio,

    @NotNull(message = "Ano de fundação é obrigatório")
    @Positive(message = "Ano de fundação deve ser maior que 0")
    Integer anoFundacao

) {

}